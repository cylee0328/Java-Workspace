package com.kh.practice.snack.run;

import com.kh.practice.snack.view.SnackMenu;

public class Run {

	public static void main(String[] args) {
		SnackMenu sm = new SnackMenu();
		
		sm.menu();

	}

}
