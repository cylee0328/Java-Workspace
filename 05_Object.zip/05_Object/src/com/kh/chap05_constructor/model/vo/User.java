package com.kh.chap05_constructor.model.vo;

public class User {

}
