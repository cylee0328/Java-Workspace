package com.kh.chap04_field.model.vo;


// 클래스 변수(Static)와 상수필드(static final)에 대해
public class FieldTest3 {

}
