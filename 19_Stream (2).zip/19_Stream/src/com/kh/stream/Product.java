package com.kh.stream;

public class Product {

}
