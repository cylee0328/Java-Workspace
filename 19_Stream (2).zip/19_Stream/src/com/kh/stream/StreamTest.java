package com.kh.stream;

public class StreamTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
