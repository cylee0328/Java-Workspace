package com.kh.practice.numRange.exception;

public class NumRangeException {

	public NumRangeException() {
		
	}
	
	public NumRangeException(String msg) {
		super();
	}
}
