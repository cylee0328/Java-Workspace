package com.kh.chap02_abstractAndInterface.part02_family.model.vo;

public class Baby {

}
